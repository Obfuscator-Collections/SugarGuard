﻿namespace SugarGuard.Protector.Enums
{
    public enum saveMode
    {
        Normal = 0,
        x86 = 1
    }
}
